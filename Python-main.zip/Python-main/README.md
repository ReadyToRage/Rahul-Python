# Python
PageObjects contains the elements of the webpage ,
Screenshots folder contains the screenshots of the testcases,
Reports folder contains the html report of the project,

run the program by using : pytest -v -s --html=report.html --self-contained-html testcases/test_run.py
